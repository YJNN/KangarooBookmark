var idCheck = false;
var nameCheck = false;
var password1Check = false;
var password2Check = false;
var phoneCheck = false;

$(document).ready(function(){
	
	$('#userId').focus();
	
	$('#userPwd1').keyup(function () {
		var regExp = /^[0-9A-Za-z]{8,12}$/;

		password1Check = false;
		$('#divPasswordCheck font').text("* 비밀번호를 확인해주세요.");
		$('#divPasswordCheck font').attr("color", "black");
		$('#divPasswordCheck font').attr("class", "notAvailable");
		
		$('#divPasswordCheck').removeClass("has-success");
		$('#divPasswordCheck').removeClass("has-error");
		
		
		if ($('#userPwd1').val() == "" ) {
			password1Check = false;
			$('#divPassword font').text("* 비밀번호를 입력해주세요.");
			$('#divPassword font').attr("color", "black");
			$('#divPassword font').attr("class", "notAvailable");
			
			$('#divPassword').removeClass("has-success");
			$('#divPassword').removeClass("has-error");
		}else if( $('#userPwd1').val().length< 8 ){
			password1Check = false;
			$('#divPassword font').text("*8자 이상");
			$('#divPassword font').attr("color", "red");
			$('#divPassword font').attr("class", "notAvailable");
			
			$('#divPassword').removeClass("has-success");
			$('#divPassword').addClass("has-error");
			
		}else {
 			password1Check = true;
			$('#divPassword font').text("* 사용이 가능합니다.");
			$('#divPassword font').attr("color", "green");
			$('#divPassword font').attr("class", "available");
			
			$('#divPassword').removeClass("has-error");
			$('#divPassword').addClass("has-success");
		}
		
	});
	
	
	//basicModalButton
	$('#basicModalButton').click(function () {
		$('#registUserButton').attr("style", "display: inline-block; margin:0px");
		$('#modalBody').attr("style", "color : #000;");
		$('#modalBody').html("가입 하시겠습니까?");
	
	});
	//resistuserButton
	$('#registUserButton').click(function () {
		
		if(idCheck==false){
			$('#modalBody').attr("style", "color : #f14444");
			$('#modalBody').html("<i class='glyphicon glyphicon-remove-circle'></i> 아이디를 입력해 주세요");
			$('#registUserButton').attr("style", "display: none");
			return ;
		}		
				
		if(password1Check==false){
			$('#modalBody').attr("style", "color : #f14444");
			$('#modalBody').html("<i class='glyphicon glyphicon-remove-circle'></i> 비밀번호를 확인해 주세요");
			$('#registUserButton').attr("style", "display: none");

			return ;
		}

	
		
		if(idCheck && password1Check){
			$('#registerUser').submit();
		}

	});
	
});


//AJAX select box
function Idcheck(input){
	
	 
	 var regExp = /^[0-9a-zA-Z]{1,8}$/;
	 
	 var divId = $('#divId');
	 		idCheck =false;
		if ($('#userId').val() == "" ) {
			$('#divId font').text("* 아이디를 입력해주세요.");
			$('#divId font').attr("color", "black");
			$('#divId font').attr("class", "notAvailable");
			
			divId.removeClass("has-success");
			divId.removeClass("has-error");
		}else if(!regExp.test($('#userId').val())){
			idCheck =false;
			$('#divId font').text("* 특수문자 또는 한글 또는 공백을 사용할 수 없습니다.");
			$('#divId font').attr("color", "red");
			$('#divId font').attr("class", "notAvailable");
			
			divId.removeClass("has-success");
			divId.addClass("has-error");
 		}else {
 			idCheck =true;
			$('#divId font').text("* 사용이 가능합니다.");
			$('#divId font').attr("color", "green");
			$('#divId font').attr("class", "available");
			
			divId.removeClass("has-error");
			divId.addClass("has-success");
		}

}



function getContextPath() {
	var hostIndex = location.href.indexOf( location.host ) + location.host.length;
	return location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
};