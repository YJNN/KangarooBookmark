$(document).ready(function(){	
	$('#registerBookmark').click(function(){
		$('#registerBM').submit();
	})
});