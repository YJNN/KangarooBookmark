$(document).ready(function(){
	

	
	$('#main').click(function () {
		var url = getContextPath() + "/index.jsp";
		$(location).attr('href',url);
	});
	
	
	
//	$('#searchListButton').click(function(){
//	$('#searchFacilityListForm').submit();
//});
//
//$('#resetFacilityListButton').click(function(){
//	$('#searchFacilityListForm').each(function(){
//		this.reset();
//	});
//});
//
//$('#registerFacility').click(function(){
//	var url = contextPath + "/admin/facility/facilityRegisterForm";
//	$(location).attr('href',url);
//});
//
	
});



// ContextPath 구하는 함수
function getContextPath() {
	var hostIndex = location.href.indexOf( location.host ) + location.host.length;
	return location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
};